"""Funciones objetivo de prueba."""
